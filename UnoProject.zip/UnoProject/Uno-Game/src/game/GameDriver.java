package game;

import game.unoGame.PlayGame;

public class GameDriver {
    public static void main(String[] args) {

        Game game = new PlayGame();
        game.play();
    }
}
