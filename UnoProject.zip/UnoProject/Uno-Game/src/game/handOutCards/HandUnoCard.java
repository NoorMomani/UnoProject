package game.handOutCards;

import gameComponent.cardDeck.CardsDeck;
import gameComponent.cards.ICard;

import java.util.LinkedList;
import java.util.List;

public class HandUnoCard implements IHandCards {
    List<ICard> handUnoCards;
    private int lastCardIndex = 0;

    public HandUnoCard() {
        CardsDeck standerCards = new CardsDeck();
        handUnoCards = standerCards.getCards();
    }

    @Override
    public List<ICard> drawCards(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Must draw positive unoGameComponent.cards but tried to draw " + n + " unoGameComponent.cards.");
        }
        List<ICard> handCard = new LinkedList<>();
        for (int i = 0; i < n; i++) {
            handCard.add(handUnoCards.get(lastCardIndex++));
        }
        return handCard;
    }

    @Override
    public ICard drawCard() {
        return handUnoCards.get(lastCardIndex++);
    }

    @Override
    public ICard drawCardToPlay() {
        ICard cardToPlay = handUnoCards.get(lastCardIndex++);
        while (cardToPlay.getValue().isSpecial()) {
            returnCardToUnoCard(cardToPlay);
            cardToPlay = handUnoCards.get(lastCardIndex++);
        }
        return cardToPlay;
    }

    @Override
    public void returnCardToUnoCard(ICard card) {
        handUnoCards.add(card);
    }


}

