package game.handOutCards;

import gameComponent.cardDeck.CardsDeck;
import gameComponent.cards.ICard;

import java.util.LinkedList;
import java.util.List;

public interface IHandCards {

    List<ICard> drawCards(int n);

    ICard drawCard();

    ICard drawCardToPlay();

    void returnCardToUnoCard(ICard card);

}
