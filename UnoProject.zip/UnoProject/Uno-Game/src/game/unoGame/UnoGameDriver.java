package game.unoGame;

import game.Game;
import game.handOutCards.HandUnoCard;
import gameComponent.cards.ICard;
import gameComponent.cards.UnoCard;
import gameComponent.cards.color.IColor;
import gameComponent.cards.color.UnoColor;
import gameComponent.cards.value.UnoCardValue;
import gameComponent.players.UnoPlayer;

import java.util.Scanner;
import java.util.Vector;

public abstract class UnoGameDriver extends Game {
    IColor wildUnoColor;

    protected UnoGameDriver() {
        System.out.print("How many players? ");
        Scanner in = new Scanner(System.in);
        numberOfPlayers = in.nextInt();
        while (numberOfPlayers < 2 || numberOfPlayers > 10) {
            System.out.println("Invalid number of unoGameComponent.players. Please enter a number between 2 and 10.");
            numberOfPlayers = in.nextInt();
        }
        this.players = new Vector<>(numberOfPlayers);
        this.handUnoCard = new HandUnoCard();

        for (int i = 1; i <= numberOfPlayers; i++) {
            System.out.print("IPlayer number " + i + " Please Enter Your Name: ");
            String name = in.next();
            players.add(new UnoPlayer(handUnoCard.drawCards(7), name));
        }
        currentPlayer = players.get(playerTurn);
        tableCard = handUnoCard.drawCardToPlay();

    }

    protected boolean checkColor(ICard chosenCard) {
        return chosenCard.getColor().equals(tableCard.getColor());
    }

    protected void moveTurn() {
        playerTurn += playDirection;
        if (playerTurn < 0) {
            playerTurn = numberOfPlayers - 1;
        }
        if (playerTurn == numberOfPlayers) {
            playerTurn = 0;
        }
        currentPlayer = players.get(playerTurn);
    }

    protected void skip() {

        moveTurn();
    }

    protected void reverse() {
        playDirection *= -1;
    }

    protected void drawTwo() {
        moveTurn();
        currentPlayer.addCards(handUnoCard.drawCards(2));
    }

    protected void drawFour() {
        wild();
        moveTurn();
        currentPlayer.addCards(handUnoCard.drawCards(4));
    }

    protected void wild() {
        System.out.println("1) Red");
        System.out.println("2) Blue");
        System.out.println("3) Yellow");
        System.out.println("4) Green");
        System.out.println("please enter the color which you want: ");
        int selectedColor = in.nextInt();
        switch (selectedColor) {
            case 1: {
                wildUnoColor = UnoColor.Red;
                break;
            }
            case 2: {
                wildUnoColor = UnoColor.Blue;
                break;
            }
            case 3: {
                wildUnoColor = UnoColor.Yellow;
                break;
            }
            case 4: {
                wildUnoColor = UnoColor.Green;
                break;
            }
        }
        tableCard = new UnoCard(wildUnoColor, UnoCardValue.NoValue);
    }

    protected boolean checkCardNumber(ICard playedCard) {
        return tableCard.getValue().getNumber() == playedCard.getValue().getNumber();
    }

    protected boolean isWildChosenCard(ICard playedCard) {
        int cardNumber = playedCard.getValue().getNumber();
        return cardNumber == 13 || cardNumber == 14;
    }

    protected boolean isCorrectCard(int indexCardChosen) {
        if (indexCardChosen >= currentPlayer.getNumberOfCards()) {
            return false;
        }
        ICard playedCard = currentPlayer.showCard(indexCardChosen);
        return isWildChosenCard(playedCard) || checkColor(playedCard) || checkCardNumber(playedCard);
    }

    protected int askToPlayCard() {
        System.out.print("Please enter indexCard you want to play ");
        int indexCardChosen = in.nextInt() - 1;
        boolean isCorrectCard = isCorrectCard(indexCardChosen);
        while (!isCorrectCard) {
            System.out.println("you entered wrong card, please enter correct card ");
            currentPlayer.printCard();
            System.out.print("Please enter --->  ");
            indexCardChosen = in.nextInt() - 1;
            isCorrectCard = isCorrectCard(indexCardChosen);
        }
        return indexCardChosen;
    }

}
