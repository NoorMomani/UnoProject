package game.unoGame;

import game.Game;
import gameComponent.cards.value.UnoCardValue;
import gameComponent.cards.ICard;

public class PlayGame extends UnoGameDriver {
    @Override
    public void play() {

        while (playing) {
            System.out.println("The currentPlayerName :" + currentPlayer.getPlayerName());
            System.out.println("You have these cards : ");
            currentPlayer.printCard();
            System.out.println("The table Card : " + tableCard.toString());
            if (!currentPlayer.canPlay(tableCard.getColor(), tableCard.getValue())) {
                System.out.println("you don't have a valid card.please hand card ");
                ICard bounceCard = handUnoCard.drawCard();
                System.out.println("you hand this card :" + bounceCard.toString());
                currentPlayer.addOneCard(bounceCard);
                currentPlayer.printCard();
            }
            if (currentPlayer.canPlay(tableCard.getColor(), tableCard.getValue())) {
                ICard chosenCard = currentPlayer.playCard(askToPlayCard());
                if (currentPlayer.shouldSayUno()) {
                    System.out.println("Uno");
                }
                if (currentPlayer.getNumberOfCards() == 0) {
                    System.out.println(currentPlayer.getPlayerName() + "is the winner");
                    calculateScoreOfAllPlayers();
                    System.out.println("The game is end ---");
                    playing = false;
                }
                tableCard = chosenCard;
                if (chosenCard.getValue().isSpecial()) {
                    if (UnoCardValue.DrawTwo.equals(chosenCard.getValue())) {
                        drawTwo();
                    } else if (UnoCardValue.Reverse.equals(chosenCard.getValue())) {
                        reverse();
                    } else if (UnoCardValue.Skip.equals(chosenCard.getValue())) {
                        skip();
                    } else if (UnoCardValue.WildDrawFour.equals(chosenCard.getValue())) {
                        drawFour();
                    } else {
                        wild();
                    }
                }
            } else {
                System.out.println("you can't play ");
            }
            moveTurn();
        }
    }
}
