package game;

import game.handOutCards.IHandCards;
import gameComponent.cards.ICard;
import gameComponent.players.IPlayer;

import java.util.List;
import java.util.Scanner;

public abstract class Game {

    protected List<IPlayer> players;

    protected IHandCards handUnoCard;

    protected ICard tableCard;

    protected int numberOfPlayers;

    protected Scanner in = new Scanner(System.in);
    protected int playerTurn = 0;

    protected int playDirection = 1;

    protected boolean playing = true;

    protected IPlayer currentPlayer;


    protected void calculateScoreOfAllPlayers() {
        for (int i = 0; i < players.size(); i++) {
            System.out.println(players.get(i).getPlayerName() + " your score = " + players.get(i).calculateScore());
        }
    }

    protected abstract void play();

}
