package gameComponent.cards;

import gameComponent.cards.color.IColor;
import gameComponent.cards.value.ICardValue;

public class UnoCard implements ICard {
    IColor unoColor;
    ICardValue unoCardValue;

    public UnoCard(final IColor unoColor, final ICardValue unoCardValue) {
        this.unoColor = unoColor;
        this.unoCardValue = unoCardValue;
    }

    @Override
    public IColor getColor() {
        return this.unoColor;
    }

    @Override
    public ICardValue getValue() {
        return this.unoCardValue;
    }

    @Override
    public String toString() {
        return unoColor.toString() + " " + unoCardValue.toString();
    }
}
