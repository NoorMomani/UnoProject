package gameComponent.cards.color;

public interface IColor {
     String getColor();
}
