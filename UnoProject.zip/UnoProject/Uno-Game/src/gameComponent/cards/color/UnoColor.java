package gameComponent.cards.color;

public enum UnoColor implements IColor {
    Red("Red"), Green("Green"), Yellow("Yellow"), Blue("Blue"), Wild("Wild");

    private String color;

    UnoColor(String color) {
        this.color = color;
    }

    @Override
    public String getColor() {
        return color;
    }
}
