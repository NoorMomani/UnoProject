package gameComponent.cards;

import gameComponent.cards.color.IColor;
import gameComponent.cards.value.ICardValue;


public interface ICard {
    IColor getColor();

    ICardValue getValue();

    String toString();

}
