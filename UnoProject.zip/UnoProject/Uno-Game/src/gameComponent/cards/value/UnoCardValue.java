package gameComponent.cards.value;

public enum UnoCardValue implements ICardValue {
    Zero(0, 0, false),
    One(1, 1, false),
    Two(2, 2, false),
    Three(3, 3, false),
    Four(4, 4, false),
    Five(5, 5, false),
    Six(6, 6, false),
    Seven(7, 7, false),
    Eight(8, 8, false),
    Nine(9, 9, false),
    DrawTwo(20, 10, true),
    Skip(20, 11, true),
    Reverse(20, 12, true),
    Wild(20, 13, true),
    NoValue(-1, -1, false),

    WildDrawFour(20, 14, true);

    private final int value;
    private final int number;
    private final boolean isSpecial;

    UnoCardValue(final int value, final int number, final boolean isSpecial) {
        this.value = value;
        this.number = number;
        this.isSpecial = isSpecial;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public int getNumber() {
        return number;
    }

    public boolean isSpecial() {
        return isSpecial;
    }
}
