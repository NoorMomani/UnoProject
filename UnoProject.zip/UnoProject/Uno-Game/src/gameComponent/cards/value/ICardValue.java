package gameComponent.cards.value;

public interface ICardValue {
    int getValue();

    int getNumber();

    boolean isSpecial();
}
