package gameComponent.players;

import gameComponent.cards.color.IColor;
import gameComponent.cards.ICard;
import gameComponent.cards.value.ICardValue;
import gameComponent.cards.value.UnoCardValue;

import java.util.List;

public class UnoPlayer implements IPlayer {
    private final List<ICard> playerCards;
    String playerName;

    public UnoPlayer(List<ICard> playerCards, String playerName) {
        ;
        this.playerCards = playerCards;
        this.playerName = playerName;

    }

    @Override
    public String getPlayerName() {
        return playerName;
    }

    @Override
    public int getNumberOfCards() {
        return playerCards.size();
    }

    @Override
    public void addOneCard(ICard card) {
        playerCards.add(card);
    }

    @Override
    public ICard showCard(int cardIndex) {

        return playerCards.get(cardIndex);
    }

    @Override
    public void addCards(List<ICard> cards) {
        playerCards.addAll(cards);
    }

    @Override
    public ICard playCard(int cardIndex) {

        return playerCards.remove(cardIndex);
    }

    @Override
    public Boolean shouldSayUno() {
        return playerCards.size() == 1;
    }

    @Override
    public void printCard() {
        for (int i = 1; i <= playerCards.size(); i++) {
            System.out.println(i + "-" + playerCards.get(i - 1).toString());
        }
    }

    @Override
    public boolean canPlay(IColor unoColor, ICardValue value) {
        for (ICard card : playerCards) {
            ICardValue unoCardValue = card.getValue();
            IColor cardUnoColor = card.getColor();
            if (UnoCardValue.Wild.equals(unoCardValue) || UnoCardValue.WildDrawFour.equals(unoCardValue)) {
                return true;
            } else if (unoColor.equals(cardUnoColor) || value.equals(unoCardValue)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int calculateScore() {
        int sum = 0;
        for (int i = 0; i < playerCards.size(); i++) {
            sum += playerCards.get(i).getValue().getValue();
        }
        return sum;
    }
}
