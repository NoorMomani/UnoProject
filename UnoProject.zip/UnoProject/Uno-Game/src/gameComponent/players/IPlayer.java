package gameComponent.players;

import gameComponent.cards.ICard;
import gameComponent.cards.color.IColor;
import gameComponent.cards.value.ICardValue;

import java.util.List;

public interface IPlayer {
    String getPlayerName();

    int getNumberOfCards();

    void addOneCard(ICard card);

    ICard showCard(int cardIndex);

    void addCards(List<ICard> cards);

    ICard playCard(int cardIndex);

    Boolean shouldSayUno();

    void printCard();

    boolean canPlay(IColor unoColor, ICardValue value);

    int calculateScore();
}

