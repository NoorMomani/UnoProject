package gameComponent.cardDeck;

import gameComponent.cards.ICard;

import java.util.List;

public interface ICardDeck {
     void buildDeck();

     void shuffle();

    List<ICard> getCards();
}
