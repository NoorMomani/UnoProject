package gameComponent.cardDeck;


import gameComponent.cards.ICard;
import gameComponent.cards.UnoCard;
import gameComponent.cards.color.IColor;
import gameComponent.cards.color.UnoColor;
import gameComponent.cards.value.ICardValue;
import gameComponent.cards.value.UnoCardValue;

import java.util.List;
import java.util.Random;
import java.util.Vector;

public class CardsDeck implements ICardDeck {

    public List<ICard> cards;

    public CardsDeck() {
        buildDeck();
        shuffle();
    }
    @Override
    public void buildDeck() {
        cards = new Vector<>();

        IColor[] unoColors = UnoColor.values();
        ICardValue[] unoCardValues = UnoCardValue.values();
        ICardValue[] specialUnoCardValues = new UnoCardValue[]{UnoCardValue.DrawTwo, UnoCardValue.Skip, UnoCardValue.Reverse};
        ICardValue[] wildCards = new UnoCardValue[]{UnoCardValue.Wild, UnoCardValue.WildDrawFour};

        for (ICardValue unoCardValue : wildCards) {
            for (int i = 0; i < 4; i++) {
                cards.add(new UnoCard(UnoColor.Wild, unoCardValue));
            }
        }
        for (int i = 0; i < unoColors.length - 1; i++) {
            IColor unoColor = unoColors[i];
            cards.add(new UnoCard(unoColor, UnoCardValue.Zero));

            for (int j = 1; j < 10; j++) {
                cards.add(new UnoCard(unoColor, unoCardValues[j]));
                cards.add(new UnoCard(unoColor, unoCardValues[j]));
            }

            for (ICardValue unoCardValue : specialUnoCardValues) {
                cards.add(new UnoCard(unoColor, unoCardValue));
                cards.add(new UnoCard(unoColor, unoCardValue));
            }
        }
    }
    @Override
    public void shuffle() {
        int n = cards.size();
        Random random = new Random();

        for (int i = 0; i < n; i++) {
            int randomValue = i + random.nextInt(n - i);
            ICard randomCard = cards.get(randomValue);
            cards.set(randomValue, cards.get(i));
            cards.set(i, randomCard);
        }
    }

    @Override
    public List<ICard> getCards() {
        return cards;
    }

}
